<?php

if(!defined('CLICKBANK')){
  include "config.php";
}

if(!(isset($admindefaults[4][2]) && $admindefaults[4][2] == "no"))  	                                                                                               
    echo '<p style="text-align: right; font-size: 8pt; margin-right: 18px"><a style="color: #898989" href="http://www.EasyViralPDFBrander.com/?r='.urlencode(base64_encode(CLICKBANK)).'" target="_blank">Powered By Easy Viral PDF Brander</a></p>';
if(!isset($_GET["iframe"])){ ?>
     </div>
<div id="footer">
</div>
</div>
<?php } ?>
</body>
</html>
