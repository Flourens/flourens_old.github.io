                   Easy Viral PDF Brander 
                        Version 2.0

***************************************************************
*                         LICENSE                             *
***************************************************************

You may use this script on as many of your own domains as you 
wish.

You may not under any circumstance distribute this script or 
any  component of it to others: you are the sole owner of this 
license.

You may only use the software to rebrand your own reports.
Hosting rebranders for other individuals is prohibited.

If you have any questions regarding these terms, or are 
interested in an alternative license, please contact Jay Hines 
at http://support.jayhines.com

***************************************************************
*                       INSTALLATION                          *
***************************************************************

To install the script, simply follow the steps presented in 
"EVPDFBRANDER Manual.pdf"

***************************************************************
*                        NEED HELP?                           *
***************************************************************

Check out the video tutorials at 
http://easyviralpdfbrander.com/tutorials.php

Support is available at  http://support.jayhines.com

***************************************************************
*                      SPECIAL THANKS                         *
***************************************************************

Thanks to Mark James for the icons used in the admin panel
http://www.famfamfam.com/lab/icons/silk/