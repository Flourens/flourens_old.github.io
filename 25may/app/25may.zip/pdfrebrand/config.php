<?php
define(FOLDER, "sc_templates");
define(PASSWORD,"99268240m");
define(CLICKBANK,"sciatica1");
?>