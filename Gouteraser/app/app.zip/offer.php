<?php
header("Location: http://d1.goutcode.pay.clickbank.net/?cbfid=27984");
?>

