<?php
header("Location: http://1.gout1.pay.clickbank.net/?cbfid=33734");
?>

